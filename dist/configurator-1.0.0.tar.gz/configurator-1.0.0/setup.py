# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['configurator']
install_requires = \
['libnacl>=1.8.0,<2.0.0', 'pytomlpp>=1.0.9,<2.0.0']

setup_kwargs = {
    'name': 'configurator',
    'version': '1.0.0',
    'description': 'Configuration file converter.',
    'long_description': None,
    'author': 'denchi',
    'author_email': 'denis.zakharov@everynet.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
